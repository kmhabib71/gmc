//our username
var name;
var connectedUser;

//connecting to our signaling server
var conn = new WebSocket('ws://localhost:9090');

conn.onopen = function () {
    console.log("Connected to the signaling server");
};

//when we got a message from a signaling server
conn.onmessage = function (msg) {
    console.log("Got message", msg.data);

    var data = JSON.parse(msg.data);

    switch (data.type) {
        case "login":
            alert(msg.data);
            handleLogin(data.successa);
            break;
            //when somebody wants to call us
        case "offer":
            //

            call_status.innerHTML = '<div class="card black white-text" style="height: 500px;width: 500px;"> <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;"> <div class="user_image" style=""> <img src="assets/images/me.jpg" class="circle" style="height:150px; width:150px;" alt=""> </div> <div class="user_name" style="padding:5px 0;font-size:18px;">Km Habib</div> <div class="user_calling_status" style="padding:15px 0;font-size:18px;">Calling...</div> <div class="calling_action" style="padding:50px 0 0 0;display:flex;"><div class="call-accept"> <i class="material-icons audio-toggle green darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">call</i></div> <div class="call-reject"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">close</i> </div> </div> </div> </div>';


            //            //            if (confirm("Do you agree?")) {
            var call_recieve = document.querySelector('.call-accept');
            call_recieve.addEventListener("click", function () {
                handleOffer(data.offer, data.name);
                callBtn.style.display = 'none';
                //                hangUpBtn.style.display = 'block';
                chat_wrap.style.display = 'block';
                call_status.innerHTML = '<div class="card white-text" style="background-color: transparent; height: 500px;width: 500px;"> <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;"> <div class="calling_action" style="padding:420px 0 0 0;display:flex;"> <div class="videocam-on"> <i class="material-icons video-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">videocam</i></div> <div class="audio-on"> <i class="material-icons audio-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">mic</i></div> <div class="call-cancel"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">call</i> </div> </div> </div> </div>';
                var video_toggle = document.querySelector('.videocam-on');
                var audio_toggle = document.querySelector('.audio-on');
                video_toggle.onclick = function () {
                    stream.getVideoTracks()[0].enabled = !(stream.getVideoTracks()[0].enabled);


                    var video_toggle_class = document.querySelector('.video-toggle');
                    if (video_toggle_class.innerText == 'videocam') {
                        video_toggle_class.innerText = "videocam_off";

                    } else {
                        video_toggle_class.innerText = "videocam";

                    }

                    //                    if (video_toggle_class.innerHTML.indexOf("videocam") != -1) {
                    //                        video_toggle_class.appendChild(document.createTextNode("videocam_off"));
                    //                    } else {
                    //                        video_toggle_class.appendChild(document.createTextNode("videocam"));
                    //                    }
                    //
                    //                    video_toggle_class.appendChild(document.createTextNode("videocam_off"));
                }

                audio_toggle.onclick = function () {
                    stream.getAudioTracks()[0].enabled = !(stream.getAudioTracks()[0].enabled);


                    var audio_toggle_class = document.querySelector('.audio-toggle');



                    if (audio_toggle_class.innerText == 'mic') {
                        audio_toggle_class.innerText = "mic_off";

                    } else {
                        audio_toggle_class.innerText = "mic";

                    }



                    //                    if (audio_toggle_class.innerHTML.indexOf("mic") != -1) {
                    //                        audio_toggle_class.appendChild(document.createTextNode("mic_off"));
                    //                    } else {
                    //                        audio_toggle_class.appendChild(document.createTextNode("mic"));
                    //                    }

                }

                hangup()
            });
            //                alert("Now you can connect with other user");
            //            } else {
            //                alert('User is not allowed');
            //            }
            break;
        case "answer":
            handleAnswer(data.answer);
            break;
            //when a remote peer sends an ice candidate to us
        case "candidate":
            handleCandidate(data.candidate);
            break;
        case "leave":
            handleLeave();
            break;
        default:
            break;
    }
};

conn.onerror = function (err) {
    console.log("Got error", err);
};

//alias for sending JSON encoded messages
function send(message) {
    //attach the other peer username to our messages
    if (connectedUser) {
        message.name = connectedUser;
    }
    //    conn.onopen = () => conn.send(JSON.stringify(message));
    conn.send(JSON.stringify(message));
};
//******
//UI selectors block
//******
var localVideo = document.querySelector('#localVideo');
var remoteVideo = document.querySelector('#remoteVideo');
var call_status = document.querySelector('.call-hang-status');

var msgInput = document.querySelector('#msgInput');
var sendMsgBtn = document.querySelector('#sendMsgBtn');

var chatArea = document.querySelector('#chatarea');
var yourConn;
var dataChannel;
var stream;
var loginPage = document.querySelector('#loginPage');
var usernameInput = document.querySelector('#usernameInput');
var loginBtn = document.querySelector('#loginBtn');

var callPage = document.querySelector('#callPage');
var callToUsernameInput = document.querySelector('#callToUsernameInput');
var callBtn = document.querySelector('#callBtn');

//var hangUpBtn = document.querySelector('#hangUpBtn');
var chat_wrap = document.querySelector('#chat-wrap');
var videocam = document.querySelector('.videocam-on');
var audio = document.querySelector('.audio-on');

//hide call page
//callPage.style.display = "none";

// Login when the user clicks the button
var url_string = window.location.href
var url = new URL(url_string);
var username = url.searchParams.get("username");

setTimeout(function () {
    if (conn.readyState === 1) {
        if (username != null) {
            name = username;

            if (name.length > 0) {
                send({
                    type: "login",
                    name: name
                });
            }


        }
    } else {
        console.log('connection is stublishing');
    }

}, 3000)

//loginBtn.addEventListener("click", function (event) {
//    name = usernameInput.value;
//
//    if (name.length > 0) {
//        send({
//            type: "login",
//            name: name
//        });
//    }
//
//
//
//});
function handleLogin(success) {

    if (success === false) {
        alert("Ooops...try a different username");
    } else {
        //        loginPage.style.display = "none";
        //        callPage.style.display = "block";

        //**********************
        //Starting a peer connection
        //**********************

        //getting local video stream
        navigator.getUserMedia = (navigator.getUserMedia ||
            navigator.webkitGetUserMedia ||
            navigator.mozGetUserMedia ||
            navigator.msGetUserMedia);
        navigator.getUserMedia({
            video: true,
            audio: false
        }, function (myStream) {
            stream = myStream;

            //displaying local video stream on the page
            localVideo.srcObject = stream;

            //using Google public stun server
            var configuration = {
                "iceServers": [{
                    "url": "stun:stun2.1.google.com:19302"
                }]
            };

            yourConn = new webkitRTCPeerConnection(configuration, {
                optional: [{
                    RtpDataChannels: true
                }]
            });

            // setup stream listening
            //Ekhane addStream er poriborte addtrack() use korte hobe.
            yourConn.addStream(stream);

            //when a remote user adds stream to the peer connection, we display it
            yourConn.onaddstream = function (e) {
                remoteVideo.srcObject = e.stream;

                callBtn.style.display = 'none';
                //                hangUpBtn.style.display = 'block';
                chat_wrap.style.display = 'block';
                call_status.innerHTML = '<div class="card white-text" style="background-color: transparent; height: 500px;width: 500px;"> <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;"> <div class="calling_action" style="padding:420px 0 0 0;display:flex;"> <div class="videocam-on"> <i class="material-icons video-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">videocam</i></div> <div class="audio-on"> <i class="material-icons audio-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">mic</i></div> <div class="call-cancel"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">call</i> </div> </div> </div> </div>';
                var video_toggle = document.querySelector('.videocam-on');
                var audio_toggle = document.querySelector('.audio-on');
                video_toggle.onclick = function () {
                    stream.getVideoTracks()[0].enabled = !(stream.getVideoTracks()[0].enabled);


                    var video_toggle_class = document.querySelector('.video-toggle');
                    if (video_toggle_class.innerText == 'videocam') {
                        video_toggle_class.innerText = "videocam_off";

                    } else {
                        video_toggle_class.innerText = "videocam";

                    }

                    //                    if (video_toggle_class.innerHTML.indexOf("videocam") != -1) {
                    //                        video_toggle_class.appendChild(document.createTextNode("videocam_off"));
                    //                    } else {
                    //                        video_toggle_class.appendChild(document.createTextNode("videocam"));
                    //                    }
                    //
                    //                    video_toggle_class.appendChild(document.createTextNode("videocam_off"));
                }

                audio_toggle.onclick = function () {
                    stream.getAudioTracks()[0].enabled = !(stream.getAudioTracks()[0].enabled);


                    var audio_toggle_class = document.querySelector('.audio-toggle');



                    if (audio_toggle_class.innerText == 'mic') {
                        audio_toggle_class.innerText = "mic_off";

                    } else {
                        audio_toggle_class.innerText = "mic";

                    }



                    //                    if (audio_toggle_class.innerHTML.indexOf("mic") != -1) {
                    //                        audio_toggle_class.appendChild(document.createTextNode("mic_off"));
                    //                    } else {
                    //                        audio_toggle_class.appendChild(document.createTextNode("mic"));
                    //                    }

                }
                console.log('user logged in');
                hangup()
            };
            // Setup ice handling
            yourConn.onicecandidate = function (event) {

                if (event.candidate) {
                    send({
                        type: "candidate",
                        candidate: event.candidate
                    });
                }

            };

            //creating data channel
            dataChannel = yourConn.createDataChannel("channel1", {
                reliable: true
            });

            dataChannel.onerror = function (error) {
                console.log("Ooops...error:", error);
            };

            //when we receive a message from the other peer, display it on the screen
            dataChannel.onmessage = function (event) {
                chatArea.innerHTML += "<div class='left-align'><img src='assets/images/other.jpg' class='caller-image circle' > " + connectedUser + ": " + event.data + "</div><br />";
            };

            dataChannel.onclose = function () {
                console.log("data channel is closed");
            };
        }, function (error) {
            console.log(error);
        });
    }
};

//initiating a call
callBtn.addEventListener("click", function () {




    var callToUsername = callToUsernameInput.value;

    if (callToUsername.length > 0) {

        connectedUser = callToUsername;
        // create an offer
        yourConn.createOffer(function (offer) {
            send({
                type: "offer",
                offer: offer
            });

            yourConn.setLocalDescription(offer);

        }, function (error) {
            alert("Error when creating an offer");
        });
    }


});
//var button = document.createElement("button");
//button.appendChild(document.createTextNode("Toggle Hold"));
//var button = document.querySelector('button.toggle-button');

//when somebody sends us an offer
function handleOffer(offer, name) {
    connectedUser = name;
    yourConn.setRemoteDescription(new RTCSessionDescription(offer));

    //create an answer to an offer
    yourConn.createAnswer(function (answer) {
        yourConn.setLocalDescription(answer);

        send({
            type: "answer",
            answer: answer
        });

    }, function (error) {
        alert("Error when creating an answer");
    });
};
//একটা বিষয়ে দক্ষতা পেট চালানোর জন্য, সব বিষয়ে জানা জীবন চালানোর জন্য।
//when we got an answer from a remote user
function handleAnswer(answer) {
  

    yourConn.setRemoteDescription(new RTCSessionDescription(answer));
    callBtn.style.display = 'none';
    //    hangUpBtn.style.display = 'block';
    chat_wrap.style.display = 'block';


};

//when we got an ice candidate from a remote user
function handleCandidate(candidate) {
    yourConn.addIceCandidate(new RTCIceCandidate(candidate));

};

//hang up
function hangup() {
    var call_cancel = document.querySelector('.call-cancel');

    call_cancel.addEventListener("click", function () {
        call_status.innerHTML = '';
        send({
            type: "leave"
        });

        handleLeave();
    });
}

function handleLeave() {
    connectedUser = null;
    remoteVideo.src = null;

    yourConn.close();
    yourConn.onicecandidate = null;
    yourConn.onaddstream = null;
    callBtn.style.display = 'block';
    chat_wrap.style.display = 'none';

};
//when user clicks the "send message" button
sendMsgBtn.addEventListener("click", function (event) {
    var val = msgInput.value;
    chatArea.innerHTML += "<div class='right-align'>" + val + " :" + name + "<img src='assets/images/me.jpg' class='caller-image circle' ></div><br />";

    //sending a message to a connected peer
    dataChannel.send(val);
    msgInput.value = "";
});
