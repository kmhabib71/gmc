//call hanging status
<style>
    .calling-status-wrap {
        height: 500px;
        width: 500px;
    }

    .call-action-wrap {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        z-index: 9;
    }

    .caller-image {
        height: 150px;
        width: 150px;
    }

    .user_name {
        padding: 5px 0;
        font-size: 18px;
    }

    .user_calling_status {
        padding: 15px 0;
        font-size: 18px;
    }

    .calling-action {
        padding: 50px 0 0 0;
        display: flex;
    }

    .audio-toggle {
        border-radius: 50%;
        padding: 8px;
        cursor: pointer;
        margin-right: 20px;
    }

    .call-reject-icon {
        border-radius: 50%;
        padding: 8px;
        cursor: pointer;
    }

</style>
// For caller in offer type under switch
<div class="card black white-text calling-status-wrap">
    <div class="call-action-wrap">
        <div class="user_image"> <img src="assets/images/me.jpg" class="circle caller-image" alt=""> </div>
        <div class="user_name">Km Habib</div>
        <div class="user_calling_status">Calling...</div>
        <div class="calling-action">
            <div class="call-accept"> <i class="material-icons audio-toggle green darken-2 white-text">call</i></div>
            <div class="call-reject"><i class="material-icons red darken-3 white-text call-reject-icon">close</i> </div>
        </div>
    </div>
</div>
//For callee under call btn action
<div class="card black white-text calling-status-wrap">
    <div class="call-action-wrap">
        <div class="user_image"> <img src="assets/images/me.jpg" class="circle caller-image" alt=""> </div>
        <div class="user_name">Km Habib</div>
        <div class="user_calling_status">Calling...</div>
        <div class="calling-action">
            <div class="call-reject"><i class="material-icons red darken-3 white-text call-reject-icon">close</i> </div>
        </div>
    </div>
</div>
<div class="card black white-text calling-status-wrap" style="height: 500px;width: 500px;">
    <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;">
        <div class="user_image" style=""> <img src="assets/images/me.jpg" class="circle" style="height:150px; width:150px;" alt=""> </div>
        <div class="user_name" style="padding:5px 0;font-size:18px;">Km Habib</div>
        <div class="user_calling_status" style="padding:15px 0;font-size:18px;">Calling...</div>
        <div class="calling_action" style="padding:50px 0 0 0;display:flex;">
            <div class="call-accept"> <i class="material-icons audio-toggle green darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">call</i></div>
            <div class="call-reject"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">close</i> </div>
        </div>
    </div>
</div>


//on call status
//in 
<style>
    .call-status-wrap {
        background-color: transparent;
        height: 500px;
        width: 500px;
    }

    .calling-wrap {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        z-index: 9;
    }

    .calling_action {
        padding: 420px 0 0 0;
        display: flex;
    }

    .video-toggle {
        border-radius: 50%;
        padding: 8px;
        cursor: pointer;
        margin-right: 20px;
    }

    .audio-on {
        border-radius: 50%;
        padding: 8px;
        cursor: pointer;
        margin-right: 20px;
    }

    .call-cancel {
        border-radius: 50%;
        padding: 8px;
        cursor: pointer;
    }

</style>


<div class="card white-text call-status-wrap">
    <div class="calling-wrap">
        <div class="calling_action">
            <div class="videocam-on"> <i class="material-icons video-toggle teal darken-2 white-text">videocam</i></div>
            <div class="audio-on"> <i class="material-icons audio-toggle teal darken-2 white-text">mic</i></div>
            <div class="call-cancel"><i class="material-icons red darken-3 white-text">call</i> </div>
        </div>
    </div>
</div>



<div class="card white-text call_status_wrap" style="background-color: transparent; height: 500px;width: 500px;">
    <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;">
        <div class="calling_action" style="padding:420px 0 0 0;display:flex;">
            <div class="videocam-on"> <i class="material-icons video-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">videocam</i></div>
            <div class="audio-on"> <i class="material-icons audio-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">mic</i></div>
            <div class="call-cancel"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">call</i> </div>
        </div>
    </div>
</div>              



//call audio video toggle in switch offer type 
<script>
    var call_recieve = document.querySelector('.call-accept');
            call_recieve.addEventListener("click", function () {
                handleOffer(data.offer, data.name);
                call_status.innerHTML = '<div class="card white-text" style="background-color: transparent; height: 500px;width: 500px;"> <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;"> <div class="calling_action" style="padding:420px 0 0 0;display:flex;"> <div class="videocam-on"> <i class="material-icons video-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">videocam</i></div> <div class="audio-on"> <i class="material-icons audio-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">mic</i></div> <div class="call-cancel"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">call</i> </div> </div> </div> </div>';
                var video_toggle = document.querySelector('.videocam-on');
                var audio_toggle = document.querySelector('.audio-on');
                video_toggle.onclick = function () {
                    stream.getVideoTracks()[0].enabled = !(stream.getVideoTracks()[0].enabled);


                    var video_toggle_class = document.querySelector('.video-toggle');
                    if (video_toggle_class.innerText == 'videocam') {
                        video_toggle_class.innerText = "videocam_off";

                    } else {
                        video_toggle_class.innerText = "videocam";

                    }

                   
                }

                audio_toggle.onclick = function () {
                    stream.getAudioTracks()[0].enabled = !(stream.getAudioTracks()[0].enabled);


                    var audio_toggle_class = document.querySelector('.audio-toggle');



                    if (audio_toggle_class.innerText == 'mic') {
                        audio_toggle_class.innerText = "mic_off";

                    } else {
                        audio_toggle_class.innerText = "mic";

                    }


                };

                hangup();
            });
            
            break;
</script>
//and in onStream event under handleLogin() function
<script>
      yourConn.onaddstream = function (e) {
                remoteVideo.srcObject = e.stream;


                call_status.innerHTML = '<div class="card white-text" style="background-color: transparent; height: 500px;width: 500px;"> <div class="calling-wrap " style="display:flex;flex-direction:column; align-items:center;justify-content:center;height:100%;z-index:9;"> <div class="calling_action" style="padding:420px 0 0 0;display:flex;"> <div class="videocam-on"> <i class="material-icons video-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">videocam</i></div> <div class="audio-on"> <i class="material-icons audio-toggle teal darken-2 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;margin-right:20px;">mic</i></div> <div class="call-cancel"><i class="material-icons red darken-3 white-text" style=" border-radius:50%;padding:8px;cursor:pointer;">call</i> </div> </div> </div> </div>';
                var video_toggle = document.querySelector('.videocam-on');
                var audio_toggle = document.querySelector('.audio-on');
                video_toggle.onclick = function () {
                    stream.getVideoTracks()[0].enabled = !(stream.getVideoTracks()[0].enabled);


                    var video_toggle_class = document.querySelector('.video-toggle');
                    if (video_toggle_class.innerText == 'videocam') {
                        video_toggle_class.innerText = "videocam_off";

                    } else {
                        video_toggle_class.innerText = "videocam";

                    }

                   
                }

                audio_toggle.onclick = function () {
                    stream.getAudioTracks()[0].enabled = !(stream.getAudioTracks()[0].enabled);


                    var audio_toggle_class = document.querySelector('.audio-toggle');



                    if (audio_toggle_class.innerText == 'mic') {
                        audio_toggle_class.innerText = "mic_off";

                    } else {
                        audio_toggle_class.innerText = "mic";

                    }


                };

                hangup();

            }


//connection closing
//hang up
function hangup() {
    chat_wrap.style.display = 'block';
    var call_cancel = document.querySelector('.call-cancel');

    call_cancel.addEventListener("click", function () {
        call_status.innerHTML = '';
        send({
            type: "leave"
        });

        handleLeave();
    });
}

function handleLeave() {
    connectedUser = null;
    remoteVideo.src = null;

    yourConn.close();
    yourConn.onicecandidate = null;
    yourConn.onaddstream = null;
    callBtn.style.display = 'block';
    chat_wrap.style.display = 'none';

};


          
</script>

