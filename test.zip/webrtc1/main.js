if (window.WebSocket) {
    console.log("WebSocket: supported");
    // ... code here for doing WebSocket stuff
} else {
    console.log("WebSocket: unsupported");
    // ... fallback mode, or error back to user
}


var ws = new WebSocket("ws://localhost:9090");

ws.onopen = function (e) {
    ws.send(JSON.stringify(stock_request));
}

function processEvent(e) {
    if (ws.readyState === WebSocket.OPEN) {
        // Socket open, send!
        ws.send(e);
    } else {
        // Show an error, queue it for sending later, etc
    }
}


var stock_request = {
    "stocks": ["AAPL", "MSFT", "AMZN", "GOOG", "YHOO"]
};
var stocks = {
    "AAPL": 0,
    "MSFT": 0,
    "AMZN": 0,
    "GOOG": 0,
    "YHOO": 0
};


var changeStockEntry = function (symbol, originalValue, newValue) {
    var valElem = $('#' + symbol + ' span');
    valElem.html(newValue.toFixed(2));
    if (newValue < originalValue) {
        valElem.addClass('label-danger');
        valElem.removeClass('label-success');
    } else if (newValue > originalValue) {
        valElem.addClass('label-success');
        valElem.removeClass('label-danger');
    }
}
// WebSocket message handler
ws.onmessage = function (e) {
    var stocksData = JSON.parse(e.data);
    for (var symbol in stocksData) {
        if (stocksData.hasOwnProperty(symbol)) {
            changeStockEntry(symbol, stocks[symbol], stocksData[symbol]);
            stocks[symbol] = stocksData[symbol];

        }
    }
};
ws.onerror = function (e) {
    console.log("WebSocket failure, error", e);
    //    handleErrors(e);
};

function processEvent(e) {
    if (ws.readyState === WebSocket.OPEN) {
        // Socket open, send!
        ws.send(e);
    } else {
        // Show an error, queue it for sending later, etc
    }
}

ws.onclose = function (e) {
    console.log(e.reason + " " + e.code);
    for (var symbol in stocks) {
        if (stocks.hasOwnProperty(symbol)) {
            stocks[symbol] = 0;
            ws.close(1000, 'WebSocket connection closed')
        }
    }
}
