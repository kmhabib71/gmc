
var url_string = window.location.href
var url = new URL(url_string);
var username = url.searchParams.get("username");


var local_video = document.querySelector("#local-video");

// navigator.getUserMedia(constraints, successCallback, errorCallback);

The MediaDevices.getUserMedia() method prompts the user for permission to use a media input which produces a MediaStream with tracks containing the requested types of media. That stream can include, for example, a video track and an audio track 


getUserMedia() method prompts the user for permission to use a media input

It returns a Promise that resolves to a MediaStream object. If the user denies permission, or matching media is not available, then the promise is rejected with NotAllowedError or NotFoundError respectively.

constraints:
The constraints parameter is a MediaStreamConstraints object with two members: video and audio, describing the media types requested.


navigator.mediaDevices.getUserMedia()({
    video: true,
    audio: false
}, function (myStream) {
    stream = myStream;

    //displaying local video stream on the page
    local_video.srcObject = stream;
}, function (error) {
    console.log(error);
});

  //**********************
    //Creating server
  //**********************

// ...............in server.js

//require our websocket library
var WebSocketServer = require('ws').Server;

//creating a websocket server at port 9090
var wss = new WebSocketServer({
    port: 9090
});

//all connected to the server users
var users = {};
var otherName;
//when a user connects to our sever
wss.on('connection', function (connection) {

    console.log("User connected");

    //when server gets a message from a connected user
    connection.on('message', function (message) {

    })

    connection.on("close", function () {
   	console.log("conection closed");
   }
   connection.send("Hello world");
})
    The following code is a helper function for sending messages to a connection
function sendToOtherUsers(connection, message) {
    connection.send(JSON.stringify(message));
}


//...............client.js
//our username
var name;
var connectedUser;

//connecting to our signaling server
var conn = new WebSocket('ws://localhost:9090');

conn.onopen = function () {
    console.log("Connected to the signaling server");
};

//when we got a message from a signaling server
conn.onmessage = function (msg) {
    console.log("Got message", msg.data);

    var data = JSON.parse(msg.data);
}
conn.onerror = function (err) {
    console.log("Got error", err);
};
  //**********************
    //Creating login system
  //**********************

1..... in client.js
setTimeout(function () {
    if (conn.readyState === 1) {
        if (username != null) {
            name = username;

            if (name.length > 0) {
                send({
                    type: "login",
                    name: name
                });
            }


        }
    } else {
        console.log('connection is stublishing');
    }

}, 3000)


    function send(message) {
    //attach the other peer username to our messages
    if (connectedUser) {
        message.name = connectedUser;
    }
    //    conn.onopen = () => conn.send(JSON.stringify(message));
    conn.send(JSON.stringify(message));
};

2.....  in server.js
		in server.js after message event ex: connection.on('message', function (message) {

		var data;

        //accepting only JSON messages
        try {
            data = JSON.parse(message);
        } catch (e) {
            console.log("Invalid JSON");
            data = {};
        }

        //switching type of the user message
        switch (data.type) {
            //when a user tries to login
            case "login":
                console.log("User logged", data.name);


                //if anyone is logged in with this username then refuse
                if (users[data.name]) {
                    sendTo(connection, {
                        type: "login",
                        success: false
                    });
                } else {
                    //save user connection on the server

                    users[data.name] = connection;
                    connection.name = data.name;

                    sendTo(connection, {
                        type: "login",
                        success: true
                    });

                }

                break;

3....... in client.js in onmessgae event ex: conn.onmessage = function (msg) {


 // console.log("Got message", msg.data);

    var data = JSON.parse(msg.data);

    switch (data.type) {
        case "login":
            handleLogin(data.successa);
            break;
            //when so

function handleLogin(success) {

    if (success === false) {
        alert("Ooops...try a different username");
    } else {
ager local video getusermida code ekhane ashbe.

    }

}


  //**********************
    //Sending offer
  //**********************
  1......create rtc peer connection in handleLogin() function //client.js

 

    2...... Innitiating call action //client.js

    //initiating a call
callBtn.addEventListener("click", function () {




    var callToUsername = callToUsernameInput.value;

    if (callToUsername.length > 0) {

        connectedUser = callToUsername;
        // create an offer
        yourConn.createOffer(function (offer) {
            send({
                type: "offer",
                offer: offer
            });

            yourConn.setLocalDescription(offer);

        }, function (error) {
            alert("Error when creating an offer");
        });
    }


});

 var configuration = {
                "iceServers": [{
                    "url": "stun:stun2.1.google.com:19302"
                }]
            };

            yourConn = new webkitRTCPeerConnection(configuration, {
                optional: [{
                    RtpDataChannels: true
                }]
            });

            // setup stream listening
            //Ekhane addStream er poriborte addtrack() use korte hobe.
            yourConn.addStream(stream);

            
3...... in server.js
case "offer":
                //for ex. UserA wants to call UserB
                console.log("Sending offer to: ", data.name);

                //if UserB exists then send him offer details
                var conn = users[data.name];

                if (conn != null) {
                    //setting that UserA connected with UserB
                    connection.otherName = data.name;

                    sendTo(conn, {
                        type: "offer",
                        offer: data.offer,
                        name: connection.name
                    });
                }

                break;
4.....in client.js
case "offer":
     handleOffer(data.offer, data.name);
     break;

//when somebody sends us an offer
function handleOffer(offer, name) {
    connectedUser = name;
    yourConn.setRemoteDescription(new RTCSessionDescription(offer));

    //create an answer to an offer
    yourConn.createAnswer(function (answer) {
        yourConn.setLocalDescription(answer);

        send({
            type: "answer",
            answer: answer
        });

    }, function (error) {
        alert("Error when creating an answer");
    });
};

  //**********************
    //creating answer
  //**********************
  1.......in server.js
  case "answer":
                console.log("Sending answer to: ", data.name);
                //for ex. UserB answers UserA
                var conn = users[data.name];

                if (conn != null) {
                    connection.otherName = data.name;
                    sendTo(conn, {
                        type: "answer",
                        answer: data.answer
                    });
                }

                break;

    2......in client.php

    function handleAnswer(answer) {

    yourConn.setRemoteDescription(new RTCSessionDescription(answer));
    callBtn.style.display = 'none';
    //    hangUpBtn.style.display = 'block';
    chat_wrap.style.display = 'block';
};


  //**********************
    //creating ice candidate
  //**********************
  Interactive Connectivity Establishment
On RTCPeerConnection, onicecandidate EventHandler specifies a function to be called when the icecandidate event occurs on an RTCPeerConnection instance. This happens whenever the local ICE agent needs to deliver a message to the other peer through the signaling server. This lets the ICE agent perform negotiation with the remote peer without the browser itself needing to know any specifics about the technology being used for signaling; 
1....... in client.js handleLogin() function after RTCPeerConnection created
  yourConn.onicecandidate = function (event) {

                if (event.candidate) {
                    send({
                        type: "candidate",
                        candidate: event.candidate
                    });
                }

            };
2...... in server.js 
                case "candidate":
                console.log("Sending candidate to:", data.name);
                var conn = users[data.name];

                if (conn != null) {
                    sendTo(conn, {
                        type: "candidate",
                        candidate: data.candidate
                    });
                }

                break;

3....... in client.js
            case "candidate":
            handleCandidate(data.candidate);
            break;


function handleCandidate(candidate) {
    yourConn.addIceCandidate(new RTCIceCandidate(candidate));

};

//**********************
    //Creating closing connection 
//**********************



//hang up
function hangup() {
    var call_cancel = document.querySelector('.call-cancel');

    call_cancel.addEventListener("click", function () {
        call_status.innerHTML = '';
        send({
            type: "leave"
        });

        handleLeave();
    });
}

function handleLeave() {
    connectedUser = null;
    remoteVideo.src = null;

    yourConn.close();
    yourConn.onicecandidate = null;
    yourConn.onaddstream = null;
    callBtn.style.display = 'block';
    chat_wrap.style.display = 'none';

};

then ice candidate

then hangout or closing connection

then data for messaging 

